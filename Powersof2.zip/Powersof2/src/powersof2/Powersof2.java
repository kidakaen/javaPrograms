
package powersof2;

public class Powersof2
{
   
    public static void main(String[] args)
    {
        int x = 0;
        double answr = 0;
        
        while (x <= 10)
        {
            answr = Math.pow(2,x);
            System.out.println("2 to the power of " + x + " is: " + answr);
            x = x + 1;
        }           
        
    }
    
}
