package spacelysprocketswitharraymikaelasmith;

import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class SpacelySprocketswithArrayMikaelaSmith
{

    public static void main(String[] args)
    {
        JFrame jf;
        JTextArea jta;
        JScrollPane jsp;

        //the following instantiantes the two objects
        jf = new JFrame();
        jta = new JTextArea();

        //text area sent to scroll pane
        jsp = new JScrollPane(jta);

        // window size/position
        jf.setSize(800, 350);
        jf.setLocation(400, 250);

        //m X stop the box
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // add scroll
        jf.add(jsp);

        jf.setVisible(true);
        
        // start of main code

        int sprocket, quantity;

        InputFile reportFile;
        reportFile = new InputFile("sprocketOrders.txt");

        int[] total;
        total = new int[50];

        while (!reportFile.eof())
        {
            sprocket = reportFile.readInt();
            quantity = reportFile.readInt();
            total[sprocket - 1] = total[sprocket - 1] + quantity;
        }

        jta.append("           SPACELY SPROCKETS           \n");
        jta.append("       Taking Sprockets into the Future       \n");
        jta.append("             Sales Summary Report             \n");
        jta.append("Sprocket Number            Total Quantity Sold \n");
        jta.append("______________________________________________\n"); 

        for (int i = 0; i < 50; i++)
        {
            jta.append("    "  + (i + 1));
            if(i < 9)
            {
                jta.append("  ");
            }
            
            jta.append(                "                                                         " + total[i] + "\n");
        }

    }

}
