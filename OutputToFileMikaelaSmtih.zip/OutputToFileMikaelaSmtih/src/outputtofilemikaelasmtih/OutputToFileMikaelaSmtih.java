
package outputtofilemikaelasmtih;


public class OutputToFileMikaelaSmtih
{

    
    public static void main(String[] args)
    {
        OutputFile payRoll;
        payRoll = new OutputFile("Payroll.txt");
        String empName, answer;
        double payRate,hours;
        Keyboard k = new Keyboard();
        
        do
        {
          System.out.println("Please enter name.");
          empName = k.readLine();
          System.out.println("Please enter pay rate.");
          payRate = k.readDouble();
          System.out.println("Please enter hours worked.");
          hours = k.readDouble();
          
          payRoll.writeString(empName);
          payRoll.writeDouble(payRate);
          payRoll.writeDouble(hours);
          payRoll.writeEOL();
          
          System.out.println("Do you have another employee? (Yes/No)");
          answer = k.readWord();
        }while (answer.equalsIgnoreCase("Yes"));
        
        payRoll.close();
        
    }
    
}
