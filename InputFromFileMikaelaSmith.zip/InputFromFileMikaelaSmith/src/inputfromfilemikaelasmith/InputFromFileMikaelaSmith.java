
package inputfromfilemikaelasmith;


public class InputFromFileMikaelaSmith
{

 
    public static void main(String[] args)
    {
        String name;
        Double hours, payRate, grossPay;
        InputFile payrollFile;
        
        
        payrollFile = new InputFile("Payroll.txt");
        
        while(!payrollFile.eof())
        {
            name = payrollFile.readString();
            payRate = payrollFile.readDouble();
            hours = payrollFile.readDouble();
            
            if (hours <= 40)
            {
                grossPay = hours * payRate;
             
            }
            else
            {   
                grossPay = (40 * payRate) + (hours-40) * 1.5 * payRate;
            
            }
            
            System.out.println(name + "'s gross pay is " + grossPay + ".");
        }       
    }
    
}
