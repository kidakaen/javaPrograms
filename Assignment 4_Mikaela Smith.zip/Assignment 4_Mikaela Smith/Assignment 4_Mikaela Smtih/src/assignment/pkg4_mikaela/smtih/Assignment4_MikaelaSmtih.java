
package assignment.pkg4_mikaela.smtih;

public class Assignment4_MikaelaSmtih
{

    public static String triangleType(int num1, int num2, int num3)
    {
        int a;
        int b;
        int c;
        int[] array;
        array = new int[3];
        array[0] = num1;
        array[1] = num2;
        array[2] = num3;
        System.out.println(array[0] + " , " + array[1] + " , " + array[2]);
        int temp;
        for(int j = 0; j < 3; j++)
        {
            for (int i = 0; i < 2; i++)
            {
                if(array[i] > array[i+1])
                {
                    temp = array[i];
                    array[i] = array[i+1];
                    array[i+1] = temp;
                }
            }
        }
        
        a = array[0];
        b = array[1];
        c = array[2];
        
        System.out.println(a + " , " + b + " , " + c);
       
        if(a + b <= c)
        {
            return "INVALID TRIANGLE";
        }
        else if(a == c)
        {
            return "EQUILATERAL";
        }
        else if(a == b || b == c)
        {
            return "ISOSCELES";
        }else
        {
            return "SCALENE";
        }
        
    }
    public static void main(String[] args)
    {
        int num1;
        int num2;
        int num3;
        String answer="yes";
        String triangle = "";
    
        Keyboard k = new Keyboard();
    

        System.out.println("Please enter the lengths of your trianle.");
        
        while (answer.equalsIgnoreCase("Yes"))
        {
          System.out.println("Please enter the length 1"); 
          num1 = k.readInt();
          System.out.println("Please enter the length 2");
          num2 = k.readInt();
          System.out.println("Please enter the length 3");
          num3 = k.readInt();
          
          
          triangle = triangleType(num1,num2,num3);
          
          System.out.println("Your triangle is a: " + triangle);
          
          System.out.println("Do you want to enter another triangle? Yes or No");
          answer = k.readLine();
          
        }
    }
}
