package output1ton_mikaelasmith;

public class Output1toN_MikaelaSmith
{

    public static void main(String[] args)
    {

        int n = 0;
        int count = 0;
        Keyboard k;
        k = new Keyboard();

        System.out.println("Enter a whole number greater than 0 ");
        n = k.readInt();

        while (count != n)
        {
            count = count + 1;
            System.out.println(count);
        }
    }

}
